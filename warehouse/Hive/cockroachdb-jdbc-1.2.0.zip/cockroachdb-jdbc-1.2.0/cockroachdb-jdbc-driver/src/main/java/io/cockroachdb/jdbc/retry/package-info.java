/**
 * This package provides repeatable history of operations and retry logic.
 */
package io.cockroachdb.jdbc.retry;
