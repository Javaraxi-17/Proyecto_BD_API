/**
 * This package provides support utilities for the CockroachDB JDBC driver.
 */
package io.cockroachdb.jdbc.util;
