/**
 * This package provides SQL query pre-processing and rewrite utilities.
 */
package io.cockroachdb.jdbc.rewrite;
